﻿
namespace DDOCP_assignment
{
    partial class frmViewSurvey
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmViewSurvey));
            this.grpYesNoQuestion = new System.Windows.Forms.GroupBox();
            this.rbtnNo = new System.Windows.Forms.RadioButton();
            this.rbtnYes = new System.Windows.Forms.RadioButton();
            this.lblYesNoQuestion = new System.Windows.Forms.Label();
            this.btnNextQuestionYesNo = new System.Windows.Forms.Button();
            this.grpDropDownQuestion = new System.Windows.Forms.GroupBox();
            this.lblOptions = new System.Windows.Forms.Label();
            this.comboBoxBoxDisplayOptions = new System.Windows.Forms.ComboBox();
            this.lblDropDownQuestion = new System.Windows.Forms.Label();
            this.btnNextQuestionDropdown = new System.Windows.Forms.Button();
            this.lblSurveyName = new System.Windows.Forms.Label();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.txtCustomer = new System.Windows.Forms.TextBox();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.txtCustomerName = new System.Windows.Forms.TextBox();
            this.pictureBox3 = new System.Windows.Forms.PictureBox();
            this.comboBoxListOfSurvey = new System.Windows.Forms.ComboBox();
            this.lblSurveyList = new System.Windows.Forms.Label();
            this.lblSurveyDescrip = new System.Windows.Forms.Label();
            this.lblSurveyText = new System.Windows.Forms.Label();
            this.lblDispalySurveyDiscrip = new System.Windows.Forms.Label();
            this.btnSurveyResponse = new System.Windows.Forms.Button();
            this.toolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.logOutToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.existToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.lblCustomerUserName = new System.Windows.Forms.Label();
            this.lblUserNameText = new System.Windows.Forms.Label();
            this.btnNextQuestionRaiting = new System.Windows.Forms.Button();
            this.lblRaitingQuestion = new System.Windows.Forms.Label();
            this.rBtnTen = new System.Windows.Forms.RadioButton();
            this.rBtnEight = new System.Windows.Forms.RadioButton();
            this.rBtnNine = new System.Windows.Forms.RadioButton();
            this.rBtnSeven = new System.Windows.Forms.RadioButton();
            this.rBtnSix = new System.Windows.Forms.RadioButton();
            this.grpRaitingQuestion = new System.Windows.Forms.GroupBox();
            this.lblNotAtAllLikely = new System.Windows.Forms.Label();
            this.rBtnOne = new System.Windows.Forms.RadioButton();
            this.lblExtremelyLikely = new System.Windows.Forms.Label();
            this.rBtnTwo = new System.Windows.Forms.RadioButton();
            this.rBtnThree = new System.Windows.Forms.RadioButton();
            this.rBtnFour = new System.Windows.Forms.RadioButton();
            this.rBtnFive = new System.Windows.Forms.RadioButton();
            this.pictureBox4 = new System.Windows.Forms.PictureBox();
            this.grpYesNoQuestion.SuspendLayout();
            this.grpDropDownQuestion.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).BeginInit();
            this.menuStrip1.SuspendLayout();
            this.grpRaitingQuestion.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).BeginInit();
            this.SuspendLayout();
            // 
            // grpYesNoQuestion
            // 
            this.grpYesNoQuestion.Controls.Add(this.rbtnNo);
            this.grpYesNoQuestion.Controls.Add(this.rbtnYes);
            this.grpYesNoQuestion.Controls.Add(this.lblYesNoQuestion);
            this.grpYesNoQuestion.Controls.Add(this.btnNextQuestionYesNo);
            this.grpYesNoQuestion.Location = new System.Drawing.Point(355, 157);
            this.grpYesNoQuestion.Name = "grpYesNoQuestion";
            this.grpYesNoQuestion.Size = new System.Drawing.Size(688, 153);
            this.grpYesNoQuestion.TabIndex = 0;
            this.grpYesNoQuestion.TabStop = false;
            this.grpYesNoQuestion.Text = "Yes No Question";
            // 
            // rbtnNo
            // 
            this.rbtnNo.AutoSize = true;
            this.rbtnNo.Location = new System.Drawing.Point(21, 115);
            this.rbtnNo.Name = "rbtnNo";
            this.rbtnNo.Size = new System.Drawing.Size(39, 17);
            this.rbtnNo.TabIndex = 33;
            this.rbtnNo.TabStop = true;
            this.rbtnNo.Text = "No";
            this.rbtnNo.UseVisualStyleBackColor = true;
            // 
            // rbtnYes
            // 
            this.rbtnYes.AutoSize = true;
            this.rbtnYes.Location = new System.Drawing.Point(21, 73);
            this.rbtnYes.Name = "rbtnYes";
            this.rbtnYes.Size = new System.Drawing.Size(43, 17);
            this.rbtnYes.TabIndex = 32;
            this.rbtnYes.Text = "Yes";
            this.rbtnYes.UseVisualStyleBackColor = true;
            // 
            // lblYesNoQuestion
            // 
            this.lblYesNoQuestion.AutoSize = true;
            this.lblYesNoQuestion.Font = new System.Drawing.Font("Bahnschrift", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblYesNoQuestion.Location = new System.Drawing.Point(18, 34);
            this.lblYesNoQuestion.Name = "lblYesNoQuestion";
            this.lblYesNoQuestion.Size = new System.Drawing.Size(45, 18);
            this.lblYesNoQuestion.TabIndex = 31;
            this.lblYesNoQuestion.Text = "label1";
            // 
            // btnNextQuestionYesNo
            // 
            this.btnNextQuestionYesNo.BackColor = System.Drawing.Color.CadetBlue;
            this.btnNextQuestionYesNo.Font = new System.Drawing.Font("Bahnschrift", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnNextQuestionYesNo.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.btnNextQuestionYesNo.Location = new System.Drawing.Point(586, 115);
            this.btnNextQuestionYesNo.Name = "btnNextQuestionYesNo";
            this.btnNextQuestionYesNo.Size = new System.Drawing.Size(102, 37);
            this.btnNextQuestionYesNo.TabIndex = 30;
            this.btnNextQuestionYesNo.Text = "Next";
            this.btnNextQuestionYesNo.UseVisualStyleBackColor = false;
            this.btnNextQuestionYesNo.Click += new System.EventHandler(this.btnNextQuestionYesNo_Click);
            // 
            // grpDropDownQuestion
            // 
            this.grpDropDownQuestion.Controls.Add(this.lblOptions);
            this.grpDropDownQuestion.Controls.Add(this.comboBoxBoxDisplayOptions);
            this.grpDropDownQuestion.Controls.Add(this.lblDropDownQuestion);
            this.grpDropDownQuestion.Controls.Add(this.btnNextQuestionDropdown);
            this.grpDropDownQuestion.Location = new System.Drawing.Point(355, 503);
            this.grpDropDownQuestion.Name = "grpDropDownQuestion";
            this.grpDropDownQuestion.Size = new System.Drawing.Size(688, 167);
            this.grpDropDownQuestion.TabIndex = 1;
            this.grpDropDownQuestion.TabStop = false;
            this.grpDropDownQuestion.Text = "Drop Down Question";
            // 
            // lblOptions
            // 
            this.lblOptions.AutoSize = true;
            this.lblOptions.Font = new System.Drawing.Font("Bahnschrift", 9.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblOptions.ForeColor = System.Drawing.SystemColors.ControlDarkDark;
            this.lblOptions.Location = new System.Drawing.Point(19, 54);
            this.lblOptions.Name = "lblOptions";
            this.lblOptions.Size = new System.Drawing.Size(292, 16);
            this.lblOptions.TabIndex = 44;
            this.lblOptions.Text = "Please select an option from the dropdown menu.\r\n";
            // 
            // comboBoxBoxDisplayOptions
            // 
            this.comboBoxBoxDisplayOptions.FormattingEnabled = true;
            this.comboBoxBoxDisplayOptions.Location = new System.Drawing.Point(317, 52);
            this.comboBoxBoxDisplayOptions.Name = "comboBoxBoxDisplayOptions";
            this.comboBoxBoxDisplayOptions.Size = new System.Drawing.Size(194, 21);
            this.comboBoxBoxDisplayOptions.TabIndex = 43;
            // 
            // lblDropDownQuestion
            // 
            this.lblDropDownQuestion.AutoSize = true;
            this.lblDropDownQuestion.Font = new System.Drawing.Font("Bahnschrift", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblDropDownQuestion.Location = new System.Drawing.Point(19, 25);
            this.lblDropDownQuestion.Name = "lblDropDownQuestion";
            this.lblDropDownQuestion.Size = new System.Drawing.Size(45, 18);
            this.lblDropDownQuestion.TabIndex = 32;
            this.lblDropDownQuestion.Text = "label1";
            // 
            // btnNextQuestionDropdown
            // 
            this.btnNextQuestionDropdown.BackColor = System.Drawing.Color.CadetBlue;
            this.btnNextQuestionDropdown.Font = new System.Drawing.Font("Bahnschrift", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnNextQuestionDropdown.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.btnNextQuestionDropdown.Location = new System.Drawing.Point(586, 130);
            this.btnNextQuestionDropdown.Name = "btnNextQuestionDropdown";
            this.btnNextQuestionDropdown.Size = new System.Drawing.Size(102, 37);
            this.btnNextQuestionDropdown.TabIndex = 31;
            this.btnNextQuestionDropdown.Text = "Next";
            this.btnNextQuestionDropdown.UseVisualStyleBackColor = false;
            this.btnNextQuestionDropdown.Click += new System.EventHandler(this.btnNextQuestionDropdown_Click);
            // 
            // lblSurveyName
            // 
            this.lblSurveyName.AutoSize = true;
            this.lblSurveyName.Font = new System.Drawing.Font("Bahnschrift", 10.25F);
            this.lblSurveyName.Location = new System.Drawing.Point(12, 104);
            this.lblSurveyName.Name = "lblSurveyName";
            this.lblSurveyName.Size = new System.Drawing.Size(48, 17);
            this.lblSurveyName.TabIndex = 2;
            this.lblSurveyName.Text = "          ";
            // 
            // pictureBox2
            // 
            this.pictureBox2.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.pictureBox2.BackgroundImage = global::DDOCP_assignment.Properties.Resources.account;
            this.pictureBox2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pictureBox2.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.pictureBox2.Location = new System.Drawing.Point(1022, 0);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(58, 50);
            this.pictureBox2.TabIndex = 18;
            this.pictureBox2.TabStop = false;
            // 
            // txtCustomer
            // 
            this.txtCustomer.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.txtCustomer.BackColor = System.Drawing.Color.CadetBlue;
            this.txtCustomer.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtCustomer.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))));
            this.txtCustomer.ForeColor = System.Drawing.SystemColors.InactiveBorder;
            this.txtCustomer.Location = new System.Drawing.Point(790, -23);
            this.txtCustomer.Multiline = true;
            this.txtCustomer.Name = "txtCustomer";
            this.txtCustomer.Size = new System.Drawing.Size(33, 20);
            this.txtCustomer.TabIndex = 19;
            this.txtCustomer.Text = "Hi";
            // 
            // pictureBox1
            // 
            this.pictureBox1.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.pictureBox1.BackColor = System.Drawing.Color.CadetBlue;
            this.pictureBox1.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.pictureBox1.Location = new System.Drawing.Point(3, -35);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(1081, 32);
            this.pictureBox1.TabIndex = 20;
            this.pictureBox1.TabStop = false;
            // 
            // txtCustomerName
            // 
            this.txtCustomerName.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.txtCustomerName.BackColor = System.Drawing.Color.CadetBlue;
            this.txtCustomerName.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtCustomerName.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))));
            this.txtCustomerName.ForeColor = System.Drawing.SystemColors.InactiveBorder;
            this.txtCustomerName.Location = new System.Drawing.Point(844, -23);
            this.txtCustomerName.Multiline = true;
            this.txtCustomerName.Name = "txtCustomerName";
            this.txtCustomerName.Size = new System.Drawing.Size(136, 20);
            this.txtCustomerName.TabIndex = 21;
            this.txtCustomerName.Text = " ";
            // 
            // pictureBox3
            // 
            this.pictureBox3.BackColor = System.Drawing.Color.CadetBlue;
            this.pictureBox3.Location = new System.Drawing.Point(304, 148);
            this.pictureBox3.Name = "pictureBox3";
            this.pictureBox3.Size = new System.Drawing.Size(15, 539);
            this.pictureBox3.TabIndex = 26;
            this.pictureBox3.TabStop = false;
            // 
            // comboBoxListOfSurvey
            // 
            this.comboBoxListOfSurvey.FormattingEnabled = true;
            this.comboBoxListOfSurvey.Location = new System.Drawing.Point(44, 390);
            this.comboBoxListOfSurvey.Name = "comboBoxListOfSurvey";
            this.comboBoxListOfSurvey.Size = new System.Drawing.Size(215, 21);
            this.comboBoxListOfSurvey.TabIndex = 31;
            this.comboBoxListOfSurvey.SelectedIndexChanged += new System.EventHandler(this.comboBoxListOfSurvey_SelectedIndexChanged);
            // 
            // lblSurveyList
            // 
            this.lblSurveyList.AutoSize = true;
            this.lblSurveyList.Font = new System.Drawing.Font("Bahnschrift", 13.25F, System.Drawing.FontStyle.Bold);
            this.lblSurveyList.Location = new System.Drawing.Point(91, 345);
            this.lblSurveyList.Name = "lblSurveyList";
            this.lblSurveyList.Size = new System.Drawing.Size(132, 22);
            this.lblSurveyList.TabIndex = 34;
            this.lblSurveyList.Text = "List of Surveys";
            // 
            // lblSurveyDescrip
            // 
            this.lblSurveyDescrip.AutoSize = true;
            this.lblSurveyDescrip.Font = new System.Drawing.Font("Bahnschrift", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblSurveyDescrip.Location = new System.Drawing.Point(322, 64);
            this.lblSurveyDescrip.Name = "lblSurveyDescrip";
            this.lblSurveyDescrip.Size = new System.Drawing.Size(137, 18);
            this.lblSurveyDescrip.TabIndex = 35;
            this.lblSurveyDescrip.Text = "Survey Description:";
            // 
            // lblSurveyText
            // 
            this.lblSurveyText.AutoSize = true;
            this.lblSurveyText.Font = new System.Drawing.Font("Bahnschrift", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblSurveyText.Location = new System.Drawing.Point(12, 66);
            this.lblSurveyText.Name = "lblSurveyText";
            this.lblSurveyText.Size = new System.Drawing.Size(101, 18);
            this.lblSurveyText.TabIndex = 36;
            this.lblSurveyText.Text = "Survey Name:";
            // 
            // lblDispalySurveyDiscrip
            // 
            this.lblDispalySurveyDiscrip.AutoSize = true;
            this.lblDispalySurveyDiscrip.Font = new System.Drawing.Font("Bahnschrift", 10.25F);
            this.lblDispalySurveyDiscrip.Location = new System.Drawing.Point(322, 104);
            this.lblDispalySurveyDiscrip.Name = "lblDispalySurveyDiscrip";
            this.lblDispalySurveyDiscrip.Size = new System.Drawing.Size(44, 17);
            this.lblDispalySurveyDiscrip.TabIndex = 37;
            this.lblDispalySurveyDiscrip.Text = "         ";
            // 
            // btnSurveyResponse
            // 
            this.btnSurveyResponse.BackColor = System.Drawing.Color.DarkOrange;
            this.btnSurveyResponse.Font = new System.Drawing.Font("Bahnschrift", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSurveyResponse.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.btnSurveyResponse.Location = new System.Drawing.Point(44, 252);
            this.btnSurveyResponse.Name = "btnSurveyResponse";
            this.btnSurveyResponse.Size = new System.Drawing.Size(215, 37);
            this.btnSurveyResponse.TabIndex = 40;
            this.btnSurveyResponse.Text = "Save Survey Response";
            this.btnSurveyResponse.UseVisualStyleBackColor = false;
            this.btnSurveyResponse.Click += new System.EventHandler(this.btnSurveyResponse_Click);
            // 
            // toolStripMenuItem1
            // 
            this.toolStripMenuItem1.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.logOutToolStripMenuItem,
            this.existToolStripMenuItem});
            this.toolStripMenuItem1.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.toolStripMenuItem1.ForeColor = System.Drawing.SystemColors.ControlText;
            this.toolStripMenuItem1.Name = "toolStripMenuItem1";
            this.toolStripMenuItem1.Padding = new System.Windows.Forms.Padding(4, 20, 4, 0);
            this.toolStripMenuItem1.Size = new System.Drawing.Size(81, 48);
            this.toolStripMenuItem1.Text = " Menu";
            // 
            // logOutToolStripMenuItem
            // 
            this.logOutToolStripMenuItem.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.logOutToolStripMenuItem.Name = "logOutToolStripMenuItem";
            this.logOutToolStripMenuItem.Size = new System.Drawing.Size(168, 24);
            this.logOutToolStripMenuItem.Text = "Log Out";
            this.logOutToolStripMenuItem.Click += new System.EventHandler(this.logOutToolStripMenuItem_Click);
            // 
            // existToolStripMenuItem
            // 
            this.existToolStripMenuItem.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.existToolStripMenuItem.Name = "existToolStripMenuItem";
            this.existToolStripMenuItem.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.X)));
            this.existToolStripMenuItem.Size = new System.Drawing.Size(168, 24);
            this.existToolStripMenuItem.Text = "Exit";
            this.existToolStripMenuItem.Click += new System.EventHandler(this.existToolStripMenuItem_Click_1);
            // 
            // menuStrip1
            // 
            this.menuStrip1.BackColor = System.Drawing.Color.CadetBlue;
            this.menuStrip1.ImageScalingSize = new System.Drawing.Size(24, 24);
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripMenuItem1});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Padding = new System.Windows.Forms.Padding(4, 1, 0, 1);
            this.menuStrip1.Size = new System.Drawing.Size(1080, 50);
            this.menuStrip1.TabIndex = 30;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // lblCustomerUserName
            // 
            this.lblCustomerUserName.AutoSize = true;
            this.lblCustomerUserName.BackColor = System.Drawing.Color.CadetBlue;
            this.lblCustomerUserName.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblCustomerUserName.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.lblCustomerUserName.Location = new System.Drawing.Point(758, 18);
            this.lblCustomerUserName.Name = "lblCustomerUserName";
            this.lblCustomerUserName.Size = new System.Drawing.Size(26, 20);
            this.lblCustomerUserName.TabIndex = 41;
            this.lblCustomerUserName.Text = "Hi";
            // 
            // lblUserNameText
            // 
            this.lblUserNameText.AutoSize = true;
            this.lblUserNameText.BackColor = System.Drawing.Color.CadetBlue;
            this.lblUserNameText.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblUserNameText.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.lblUserNameText.Location = new System.Drawing.Point(788, 18);
            this.lblUserNameText.Name = "lblUserNameText";
            this.lblUserNameText.Size = new System.Drawing.Size(57, 20);
            this.lblUserNameText.TabIndex = 42;
            this.lblUserNameText.Text = "label1";
            // 
            // btnNextQuestionRaiting
            // 
            this.btnNextQuestionRaiting.BackColor = System.Drawing.Color.CadetBlue;
            this.btnNextQuestionRaiting.Font = new System.Drawing.Font("Bahnschrift", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnNextQuestionRaiting.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.btnNextQuestionRaiting.Location = new System.Drawing.Point(586, 145);
            this.btnNextQuestionRaiting.Name = "btnNextQuestionRaiting";
            this.btnNextQuestionRaiting.Size = new System.Drawing.Size(102, 37);
            this.btnNextQuestionRaiting.TabIndex = 32;
            this.btnNextQuestionRaiting.Text = "Next";
            this.btnNextQuestionRaiting.UseVisualStyleBackColor = false;
            this.btnNextQuestionRaiting.Click += new System.EventHandler(this.btnNextQuestionRaiting_Click);
            // 
            // lblRaitingQuestion
            // 
            this.lblRaitingQuestion.AutoSize = true;
            this.lblRaitingQuestion.Font = new System.Drawing.Font("Bahnschrift", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblRaitingQuestion.Location = new System.Drawing.Point(15, 34);
            this.lblRaitingQuestion.Name = "lblRaitingQuestion";
            this.lblRaitingQuestion.Size = new System.Drawing.Size(45, 18);
            this.lblRaitingQuestion.TabIndex = 30;
            this.lblRaitingQuestion.Text = "label1";
            // 
            // rBtnTen
            // 
            this.rBtnTen.AutoSize = true;
            this.rBtnTen.Location = new System.Drawing.Point(645, 72);
            this.rBtnTen.Name = "rBtnTen";
            this.rBtnTen.Size = new System.Drawing.Size(37, 17);
            this.rBtnTen.TabIndex = 33;
            this.rBtnTen.TabStop = true;
            this.rBtnTen.Text = "10";
            this.rBtnTen.UseVisualStyleBackColor = true;
            // 
            // rBtnEight
            // 
            this.rBtnEight.AutoSize = true;
            this.rBtnEight.Location = new System.Drawing.Point(502, 72);
            this.rBtnEight.Name = "rBtnEight";
            this.rBtnEight.Size = new System.Drawing.Size(31, 17);
            this.rBtnEight.TabIndex = 34;
            this.rBtnEight.TabStop = true;
            this.rBtnEight.Text = "8";
            this.rBtnEight.UseVisualStyleBackColor = true;
            // 
            // rBtnNine
            // 
            this.rBtnNine.AutoSize = true;
            this.rBtnNine.Location = new System.Drawing.Point(579, 72);
            this.rBtnNine.Name = "rBtnNine";
            this.rBtnNine.Size = new System.Drawing.Size(31, 17);
            this.rBtnNine.TabIndex = 36;
            this.rBtnNine.TabStop = true;
            this.rBtnNine.Text = "9";
            this.rBtnNine.UseVisualStyleBackColor = true;
            // 
            // rBtnSeven
            // 
            this.rBtnSeven.AutoSize = true;
            this.rBtnSeven.Location = new System.Drawing.Point(432, 72);
            this.rBtnSeven.Name = "rBtnSeven";
            this.rBtnSeven.Size = new System.Drawing.Size(31, 17);
            this.rBtnSeven.TabIndex = 37;
            this.rBtnSeven.TabStop = true;
            this.rBtnSeven.Text = "7";
            this.rBtnSeven.UseVisualStyleBackColor = true;
            // 
            // rBtnSix
            // 
            this.rBtnSix.AutoSize = true;
            this.rBtnSix.Location = new System.Drawing.Point(360, 72);
            this.rBtnSix.Name = "rBtnSix";
            this.rBtnSix.Size = new System.Drawing.Size(31, 17);
            this.rBtnSix.TabIndex = 39;
            this.rBtnSix.TabStop = true;
            this.rBtnSix.Text = "6";
            this.rBtnSix.UseVisualStyleBackColor = true;
            // 
            // grpRaitingQuestion
            // 
            this.grpRaitingQuestion.Controls.Add(this.lblNotAtAllLikely);
            this.grpRaitingQuestion.Controls.Add(this.rBtnOne);
            this.grpRaitingQuestion.Controls.Add(this.lblExtremelyLikely);
            this.grpRaitingQuestion.Controls.Add(this.rBtnTwo);
            this.grpRaitingQuestion.Controls.Add(this.rBtnThree);
            this.grpRaitingQuestion.Controls.Add(this.rBtnFour);
            this.grpRaitingQuestion.Controls.Add(this.rBtnFive);
            this.grpRaitingQuestion.Controls.Add(this.lblRaitingQuestion);
            this.grpRaitingQuestion.Controls.Add(this.rBtnSix);
            this.grpRaitingQuestion.Controls.Add(this.rBtnSeven);
            this.grpRaitingQuestion.Controls.Add(this.rBtnNine);
            this.grpRaitingQuestion.Controls.Add(this.rBtnEight);
            this.grpRaitingQuestion.Controls.Add(this.rBtnTen);
            this.grpRaitingQuestion.Controls.Add(this.btnNextQuestionRaiting);
            this.grpRaitingQuestion.Location = new System.Drawing.Point(355, 315);
            this.grpRaitingQuestion.Name = "grpRaitingQuestion";
            this.grpRaitingQuestion.Size = new System.Drawing.Size(688, 182);
            this.grpRaitingQuestion.TabIndex = 1;
            this.grpRaitingQuestion.TabStop = false;
            this.grpRaitingQuestion.Text = "Raiting Question";
            // 
            // lblNotAtAllLikely
            // 
            this.lblNotAtAllLikely.AutoSize = true;
            this.lblNotAtAllLikely.Font = new System.Drawing.Font("Bahnschrift", 9.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblNotAtAllLikely.ForeColor = System.Drawing.SystemColors.ControlDarkDark;
            this.lblNotAtAllLikely.Location = new System.Drawing.Point(12, 103);
            this.lblNotAtAllLikely.Name = "lblNotAtAllLikely";
            this.lblNotAtAllLikely.Size = new System.Drawing.Size(94, 16);
            this.lblNotAtAllLikely.TabIndex = 46;
            this.lblNotAtAllLikely.Text = "Not at all likely";
            // 
            // rBtnOne
            // 
            this.rBtnOne.AutoSize = true;
            this.rBtnOne.Location = new System.Drawing.Point(15, 72);
            this.rBtnOne.Name = "rBtnOne";
            this.rBtnOne.Size = new System.Drawing.Size(31, 17);
            this.rBtnOne.TabIndex = 44;
            this.rBtnOne.TabStop = true;
            this.rBtnOne.Text = "1";
            this.rBtnOne.UseVisualStyleBackColor = true;
            // 
            // lblExtremelyLikely
            // 
            this.lblExtremelyLikely.AutoSize = true;
            this.lblExtremelyLikely.Font = new System.Drawing.Font("Bahnschrift", 9.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblExtremelyLikely.ForeColor = System.Drawing.SystemColors.ControlDarkDark;
            this.lblExtremelyLikely.Location = new System.Drawing.Point(580, 103);
            this.lblExtremelyLikely.Name = "lblExtremelyLikely";
            this.lblExtremelyLikely.Size = new System.Drawing.Size(102, 16);
            this.lblExtremelyLikely.TabIndex = 45;
            this.lblExtremelyLikely.Text = "Extremely likely";
            // 
            // rBtnTwo
            // 
            this.rBtnTwo.AutoSize = true;
            this.rBtnTwo.Location = new System.Drawing.Point(74, 72);
            this.rBtnTwo.Name = "rBtnTwo";
            this.rBtnTwo.Size = new System.Drawing.Size(31, 17);
            this.rBtnTwo.TabIndex = 43;
            this.rBtnTwo.TabStop = true;
            this.rBtnTwo.Text = "2";
            this.rBtnTwo.UseVisualStyleBackColor = true;
            // 
            // rBtnThree
            // 
            this.rBtnThree.AutoSize = true;
            this.rBtnThree.Location = new System.Drawing.Point(147, 72);
            this.rBtnThree.Name = "rBtnThree";
            this.rBtnThree.Size = new System.Drawing.Size(31, 17);
            this.rBtnThree.TabIndex = 42;
            this.rBtnThree.TabStop = true;
            this.rBtnThree.Text = "3";
            this.rBtnThree.UseVisualStyleBackColor = true;
            // 
            // rBtnFour
            // 
            this.rBtnFour.AutoSize = true;
            this.rBtnFour.Location = new System.Drawing.Point(217, 72);
            this.rBtnFour.Name = "rBtnFour";
            this.rBtnFour.Size = new System.Drawing.Size(31, 17);
            this.rBtnFour.TabIndex = 41;
            this.rBtnFour.TabStop = true;
            this.rBtnFour.Text = "4";
            this.rBtnFour.UseVisualStyleBackColor = true;
            // 
            // rBtnFive
            // 
            this.rBtnFive.AutoSize = true;
            this.rBtnFive.Location = new System.Drawing.Point(290, 72);
            this.rBtnFive.Name = "rBtnFive";
            this.rBtnFive.Size = new System.Drawing.Size(31, 17);
            this.rBtnFive.TabIndex = 40;
            this.rBtnFive.TabStop = true;
            this.rBtnFive.Text = "5";
            this.rBtnFive.UseVisualStyleBackColor = true;
            // 
            // pictureBox4
            // 
            this.pictureBox4.BackColor = System.Drawing.Color.CadetBlue;
            this.pictureBox4.Location = new System.Drawing.Point(0, 135);
            this.pictureBox4.Name = "pictureBox4";
            this.pictureBox4.Size = new System.Drawing.Size(1080, 16);
            this.pictureBox4.TabIndex = 43;
            this.pictureBox4.TabStop = false;
            // 
            // frmViewSurvey
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1080, 687);
            this.Controls.Add(this.pictureBox4);
            this.Controls.Add(this.lblUserNameText);
            this.Controls.Add(this.lblCustomerUserName);
            this.Controls.Add(this.btnSurveyResponse);
            this.Controls.Add(this.lblDispalySurveyDiscrip);
            this.Controls.Add(this.lblSurveyText);
            this.Controls.Add(this.lblSurveyDescrip);
            this.Controls.Add(this.lblSurveyList);
            this.Controls.Add(this.comboBoxListOfSurvey);
            this.Controls.Add(this.pictureBox3);
            this.Controls.Add(this.txtCustomerName);
            this.Controls.Add(this.pictureBox2);
            this.Controls.Add(this.lblSurveyName);
            this.Controls.Add(this.txtCustomer);
            this.Controls.Add(this.grpRaitingQuestion);
            this.Controls.Add(this.grpDropDownQuestion);
            this.Controls.Add(this.grpYesNoQuestion);
            this.Controls.Add(this.menuStrip1);
            this.Controls.Add(this.pictureBox1);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MainMenuStrip = this.menuStrip1;
            this.MaximumSize = new System.Drawing.Size(1096, 726);
            this.MinimumSize = new System.Drawing.Size(1096, 726);
            this.Name = "frmViewSurvey";
            this.Text = "View Survey";
            this.Load += new System.EventHandler(this.FrmViewSurvey_Load);
            this.grpYesNoQuestion.ResumeLayout(false);
            this.grpYesNoQuestion.PerformLayout();
            this.grpDropDownQuestion.ResumeLayout(false);
            this.grpDropDownQuestion.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).EndInit();
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.grpRaitingQuestion.ResumeLayout(false);
            this.grpRaitingQuestion.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.GroupBox grpYesNoQuestion;
        private System.Windows.Forms.GroupBox grpDropDownQuestion;
        private System.Windows.Forms.Label lblSurveyName;
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.TextBox txtCustomer;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.TextBox txtCustomerName;
        private System.Windows.Forms.RadioButton rbtnNo;
        private System.Windows.Forms.RadioButton rbtnYes;
        private System.Windows.Forms.Label lblYesNoQuestion;
        private System.Windows.Forms.Button btnNextQuestionYesNo;
        private System.Windows.Forms.Label lblDropDownQuestion;
        private System.Windows.Forms.Button btnNextQuestionDropdown;
        private System.Windows.Forms.PictureBox pictureBox3;
        private System.Windows.Forms.ComboBox comboBoxListOfSurvey;
        private System.Windows.Forms.Label lblSurveyList;
        private System.Windows.Forms.Label lblSurveyDescrip;
        private System.Windows.Forms.Label lblSurveyText;
        private System.Windows.Forms.Label lblDispalySurveyDiscrip;
        private System.Windows.Forms.Button btnSurveyResponse;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem logOutToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem existToolStripMenuItem;
        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.Label lblCustomerUserName;
        private System.Windows.Forms.Label lblUserNameText;
        private System.Windows.Forms.Button btnNextQuestionRaiting;
        private System.Windows.Forms.Label lblRaitingQuestion;
        private System.Windows.Forms.RadioButton rBtnTen;
        private System.Windows.Forms.RadioButton rBtnEight;
        private System.Windows.Forms.RadioButton rBtnNine;
        private System.Windows.Forms.RadioButton rBtnSeven;
        private System.Windows.Forms.RadioButton rBtnSix;
        private System.Windows.Forms.GroupBox grpRaitingQuestion;
        private System.Windows.Forms.RadioButton rBtnOne;
        private System.Windows.Forms.RadioButton rBtnTwo;
        private System.Windows.Forms.RadioButton rBtnThree;
        private System.Windows.Forms.RadioButton rBtnFour;
        private System.Windows.Forms.RadioButton rBtnFive;
        private System.Windows.Forms.ComboBox comboBoxBoxDisplayOptions;
        private System.Windows.Forms.Label lblNotAtAllLikely;
        private System.Windows.Forms.Label lblExtremelyLikely;
        private System.Windows.Forms.Label lblOptions;
        private System.Windows.Forms.PictureBox pictureBox4;
    }
}